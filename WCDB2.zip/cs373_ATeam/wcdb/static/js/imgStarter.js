(function ($) {
	$('#myCarousel .item').first().addClass('active');
	
})(jQuery);
(function ($) {
	$('#pad-wrapper').removeClass("settings-wrapper");
	$('#pad-wrapper').addClass("users-list");

	
})(jQuery);